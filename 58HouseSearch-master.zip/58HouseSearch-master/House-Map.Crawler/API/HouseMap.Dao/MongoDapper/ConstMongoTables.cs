

namespace HouseMapConsumer.Dao
{
    public class ConstMongoTables
    {
        public static string HouseData = "houseData";
    }
}