module.exports = {
  baseUrl: './',
  assetsDir: 'resource',
  devServer: {
    proxy: 'https://house-map.cn/'
  }
}
