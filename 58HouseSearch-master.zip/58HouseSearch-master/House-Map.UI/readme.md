# House-Map.UI

使用vue.js重写 UI...

API 地址:[showdoc-house-map](https://www.showdoc.cc/web/#/house)


## 安装

```sh

$  npm i
```

## 运行

```sh
$  npm run serve
```

## 打包

```sh
$  npm run build
```

## docker build

```sh
docker build .
```